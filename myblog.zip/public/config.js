const config= {
  "API_URL": "http://43.136.122.75:8080/api",
  "MapKey": "NHLBZ-LRM6U-ER2VE-4RJPZ-VUFVH-27BED"
}

export default config