 <template>
    <el-card>
        <template #header>推荐博文</template>
        <div>test</div>
    </el-card>
</template>


<script>
    export default {
        name: 'Recommend',
        data() {
            return {
                key: 'value'
            }
        },
    }
</script>


<style scoped>
</style>