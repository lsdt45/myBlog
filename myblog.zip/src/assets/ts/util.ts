import { jsonp } from 'vue-jsonp'
import config from 'public/config'
// 获取访问用户的ip和地区信息
export function getIpConfig() {
  return new Promise((resolve, reject) => {
    jsonp(`https://apis.map.qq.com/ws/location/v1/ip?key=${config.MapKey}`, {
      output: 'jsonp'
    }).then(resp => {
      resolve(resp)
    }).catch(err => {
      console.error(err)
    })
  })
}