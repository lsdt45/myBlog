 export interface Article {
  id: number;
  title: string; // 标题
  content: string; // 内容
  Introduction: string; // 简介
  commentNum: number; // 评论数
  readNum: number; // 阅读数
}