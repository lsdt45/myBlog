
// declare module 'common' {
//   export interface Article {
//     id: number;
//     title: string; // 标题
//     content: string; // 内容
//     Introduction: string; // 简介
//   }
// }